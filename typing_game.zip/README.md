## The Typing Game

Just a small game for enjoy your keyboard sound
